package edu.asupoly.ser422.restexample.model;

import java.net.URI;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AuthorBook {
	public AuthorBook() {}
	
	public AuthorBook(int id, String lname, String fname, int bid) {
		__id = id;
		__lastName  = lname;
		__firstName = fname;
		bookId = bid;
	}
	public int getAuthorId() {
		return __id;
	}
	public String getLastName() {
		return __lastName;
	}
	public String getFirstName() {
		return __firstName;
	}

	public void setAuthorId(int __id) {
		this.__id = __id;
	}
	public void setLastName(String __lastName) {
		this.__lastName = __lastName;
	}
	public void setFirstName(String __firstName) {
		this.__firstName = __firstName;
	}
	
	public String toString() {
		return "Author ID " + getAuthorId() + ", lastName " + getLastName() + ", firstName " + getFirstName();
	}
	public URI getBookURI() {
		return bookURI;
	}

	public void setBookURI(URI bookURI) {
		this.bookURI = bookURI;
	}
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	private int    __id;
	private String __lastName;
	private String __firstName;
	private URI bookURI;
	private int bookId;
}
