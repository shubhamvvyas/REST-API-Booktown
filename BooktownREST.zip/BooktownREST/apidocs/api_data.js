define({ "api": [
  {
    "type": "post",
    "url": "authors/",
    "title": "Create an Author",
    "name": "createAuthor",
    "group": "Authors",
    "description": "<p>Author can be created by passing plain/text payload(in the body). Text to be sent is of the format first_name last_name</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 CREATED\n\t[{ \"Author\": \"30017\" }]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 400 BAD REQUEST\n\t{\n\t\t\"PROVIDE VALID INPUT!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"EXCEPTION INSERTING INTO DATABASE!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"ERROR INSERTING INTO DATABASE!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/AuthorResource.java",
    "groupTitle": "Authors"
  },
  {
    "type": "delete",
    "url": "authors?id={enter_ID_here}",
    "title": "Delete an Author",
    "name": "deleteAuthor",
    "group": "Authors",
    "description": "<p>Author can be deleted by passing id as a query parameter as shown: path-to-booktownrest-api.com/authors?id={authorId} Be careful while deleting the Author since it has a reference in Book data.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 NO CONTENT",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 NOT FOUND\n{ \"message\" : \"No such Author {authorId}\"}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/AuthorResource.java",
    "groupTitle": "Authors"
  },
  {
    "type": "get",
    "url": "authors/{author_id}",
    "title": "Get Author by ID",
    "name": "getAuthor",
    "group": "Authors",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n[{\n\t\"authorId\": 1111,\n\t\"authorUri\": \"http://localhost:8080/RestExampleAPI/rest/authors/1111\",\n\t\"firstName\": \"Ariel\",\n\t\"lastName\": \"Denham\"\n}]",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "\tHTTP/1.1 404 NOT FOUND\n{\n\t \"Message\" : Sorry! Author ID not present!\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 400 BAD REQUEST\n\t{\n\t\t\"Error\": \"Provide valid input!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"Error\": \"Internal Server Error.\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/AuthorResource.java",
    "groupTitle": "Authors"
  },
  {
    "type": "get",
    "url": "authors",
    "title": "Get list of Authors",
    "name": "getAuthors",
    "group": "Authors",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\tHTTP/1.1 200 OK\n\t[{\n\t\t\"authorId\": 1111,\n\t\t\"authorUri\": \"http://localhost:8080/RestExampleAPI/rest/authors/1111\",\n\t\t\"firstName\": \"Ariel\",\n\t\t\"lastName\": \"Denham\"\n\t},\n\t{\n\t\t\"authorId\": 1212,\n\t\t\"authorUri\": \"http://localhost:8080/RestExampleAPI/rest/authors/1212\",\n\t\t\"firstName\": \"John\",\n\t\t\"lastName\": \"Worsley\"\n\t}\n ]",
          "type": "json"
        },
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 NO CONTENT\n{\n\t\"Message\" : Sorry! No Authors present!\t\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/AuthorResource.java",
    "groupTitle": "Authors",
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "type": "400",
            "optional": false,
            "field": "BadRequest",
            "description": "<p>Bad Request Encountered</p>"
          }
        ],
        "Error 5xx": [
          {
            "group": "Error 5xx",
            "type": "500",
            "optional": false,
            "field": "InternalServerError",
            "description": "<p>Something went wrong at server, Please contact the administrator!</p>"
          }
        ]
      }
    }
  },
  {
    "type": "put",
    "url": "authors/",
    "title": "Update an Author",
    "name": "updateAuthor",
    "group": "Authors",
    "description": "<p>Author can be updated by passing application/json payload(in the body). Text to be sent is of the format: { &quot;authorIdent&quot;: id, &quot;fName&quot;: firstNameInStringFormat, &quot;lName&quot;: lastNameInStringformat }</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n\t\"authorIdent\": 30017,\n\t\"fName\": \"Raghu\",\n\t\"lName\": \"Pathi\",\n\t\"authorUri\": \"http://localhost:8080/RestExampleAPI/rest/authors/30017\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 404 NOT FOUND\n\t{\n\t\t\"message\" : \"No such author {authorId}.\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"message\" : \"Internal server error deserializing Author JSON\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/AuthorResource.java",
    "groupTitle": "Authors"
  },
  {
    "type": "post",
    "url": "books/",
    "title": "Create a Book",
    "name": "createBook",
    "group": "Books",
    "description": "<p>Book record can be created by passing 'application/json' payload(in the body). Text to be sent is of the exact same format as shown below { &quot;title&quot;: &quot;The Book Thief&quot;, &quot;authorId&quot;: 4156, &quot;subjectId&quot;: 5 }</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 CREATED\n\t[{ \"Book\": \"30017\" }]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 400 BAD REQUEST\n\t{\n\t\t\"Error\": \"Please check payload data and try again!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 415 UNSUPPORTED MEDIA TYPE\n\t{\n\t\t\"Error\": \"Please use application/json as content type and check payload data!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"Error\": \"Internal Server Error. TRY AGAIN LATER!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/BookResource.java",
    "groupTitle": "Books"
  },
  {
    "type": "delete",
    "url": "books?id={enter_ID_here}",
    "title": "Delete a Book",
    "name": "deleteBook",
    "group": "Books",
    "description": "<p>A Book can be deleted by passing id as a query parameter as shown: path-to-booktownrest-api.com/books?id={bookId}</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n\"SuccessMessage\": \"Deleted item:-50022\"\n}",
          "type": "json"
        },
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 204 NO CONTENT\n{ \n\"Message\": \"ID not found!\" \n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 BAD REQUEST\n{ \n\"Error\" : \"Provide valid numeric input!\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 SERVER ERROR\n{\n\"Server Error\": \"Unable to process request. Try again!\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/BookResource.java",
    "groupTitle": "Books"
  },
  {
    "type": "get",
    "url": "books/{bookId}/author",
    "title": "Get Author of the Book",
    "name": "findAuthorOfBook",
    "group": "Books",
    "description": "<p>findAuthorOfBook provides the author information based on the Book. If Author has been deleted from the record, it cannot be retrieved.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"bookURI\": \"http://localhost:8080/RestExampleAPI/rest/books/1501\",\n\"bookId\": 1501,\n\"authorId\": 2031,\n\"lastName\": \"Brown\",\n\"firstName\": \"Margaret Wise\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 BAD REQUEST\n{ \n\"Error\" : \"Provide valid numeric input!\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 INTERNAL SERVER ERROR\n\t{\n\t\t\"message\": \"THERE SEEMS TO BE SOME ERROR ON OUR SIDE! TRY AGAIN LATER!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/BookResource.java",
    "groupTitle": "Books"
  },
  {
    "type": "get",
    "url": "books/{book_id}",
    "title": "Get Book by ID",
    "name": "getBook",
    "group": "Books",
    "description": "<p>getBook is used to get Book information based on the ID. &quot;referer&quot; attribute in the response would return 'null' if the resource is accessed using URI and would have URI of the previous resource if accessed through hyperlink.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n[{\n\"bookID\": 7808,\n\"title\": \"The Shining\",\n\"authorId\": 4156,\n\"subjectId\": 7808,\n\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/7808\",\n\"referer\": null\n}]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 404 NOT FOUND\n\t{\n\t\t\"Error\": \"No Content!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 BAD REQUEST\n{ \n\"Error\" : \"Provide valid numeric input!\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"Error\": \"Internal Server Error.\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/BookResource.java",
    "groupTitle": "Books"
  },
  {
    "type": "get",
    "url": "books",
    "title": "Get list of Books",
    "name": "getBooks",
    "group": "Books",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\tHTTP/1.1 200 OK\n[{\n\t\"authorId\": 1809,\n\t\"bookId\": 1590,\n\t\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/1590\",\n\t\"subjectId\": 2,\n\t\"title\": \"Bartholomew and the Oobleck\"\n}\n{\n\t\"authorId\": 15990,\n\t\"bookId\": 25908,\n\t\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/25908\",\n\t\"subjectId\": 2,\n\t\"title\": \"Franklin in the Dark\"\n}]",
          "type": "json"
        },
        {
          "title": "Success-Response:",
          "content": "\tHTTP/1.1 204 NO CONTENT\n{\n\t\"Message\": \"No Books in the records!\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"message\": \"Request cannot be processed now. TRY AGAIN LATER!\"\n\t}",
          "type": "json"
        }
      ],
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "type": "400",
            "optional": false,
            "field": "BadRequest",
            "description": "<p>Bad Request Encountered</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/BookResource.java",
    "groupTitle": "Books"
  },
  {
    "type": "get",
    "url": "subjects/{subjectId}/books",
    "title": "Get Books from Subject ID",
    "name": "findBooksBySubject",
    "group": "Subjects",
    "description": "<p>findBooksBySubject provides the list of books for particular subject. Subject ID has to be mentioned in the URI in order to get the list</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"authorId\": 1809,\n\"bookId\": 1608,\n\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/1608\",\n\"subjectId\": 2,\n\"title\": \"The Cat in the Hat\"\n},\n  {\n\"authorId\": 1809,\n\"bookId\": 1590,\n\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/1590\",\n\"subjectId\": 2,\n\"title\": \"Bartholomew and the Oobleck\"\n}",
          "type": "json"
        },
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 204 NO CONTENT\n\t{\n\t\t\"Message\": \"No Content!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 BAD REQUEST\n{ \n\"Error\" : \"Provide valid numeric input for Subject ID!\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 INTERNAL SERVER ERROR\n\t{\n\t\t\"Error\": \"Internal Server Error. TRY LATER\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/SubjectResource.java",
    "groupTitle": "Subjects"
  },
  {
    "type": "get",
    "url": "subjects/locations/{loc}/authors",
    "title": "Get Authors from the Location Substring",
    "name": "getAuthorsByLocation",
    "group": "Subjects",
    "description": "<p>getAuthorsByLocation returns a list of Authors who own a book in that Subject. URI can be provided as path-to-api/subjects/authors/locations/{loc} where loc is the location substring.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"authorId\": 1809,\n\"bookId\": 1608,\n\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/1608\",\n\"subjectId\": 2,\n\"title\": \"The Cat in the Hat\"\n},\n  {\n\"authorId\": 1809,\n\"bookId\": 1590,\n\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/1590\",\n\"subjectId\": 2,\n\"title\": \"Bartholomew and the Oobleck\"\n}",
          "type": "json"
        },
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 204 NO CONTENT\n\t{\n\t\t\"Message\": \"No Data found! Try another substring!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 INTERNAL SERVER ERROR\n\t{\n\t\t\"Server Error\": \"Unable to process request. Try again!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/SubjectResource.java",
    "groupTitle": "Subjects"
  },
  {
    "type": "get",
    "url": "subjects/{subject_id}",
    "title": "Get Subject by ID",
    "name": "getSubject",
    "group": "Subjects",
    "description": "<p>getSubject is used to get Subject information based on the ID. 'SelfURI' has the hyperlink navigating to itself. &quot;referer&quot; attribute in the response would return 'null' if the resource is accessed using URI and would have URI of the previous resource if accessed through hyperlink.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n[{\n\"bookID\": 7808,\n\"title\": \"The Shining\",\n\"authorId\": 4156,\n\"subjectId\": 7808,\n\"selfUri\": \"http://localhost:8080/RestExampleAPI/rest/books/7808\",\n\"referer\": null\n}]",
          "type": "json"
        },
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 204 NO CONTENT\n\t{\n\t\t\"Error\": \"No Content!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 BAD REQUEST\n{ \n\"Error\" : \"Provide valid numeric input!\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"Error\": \"Internal Server Error. TRY LATER\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/SubjectResource.java",
    "groupTitle": "Subjects"
  },
  {
    "type": "get",
    "url": "subjects",
    "title": "Get list of Subjects",
    "name": "getSubjects",
    "group": "Subjects",
    "description": "<p>Each of the response object has a hyperlink field &quot;subjectURI&quot; which can be used to navigate to the subject.</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"location\": \"Productivity Ave\",\n\"subject\": \"Computers\",\n\"subjectId\": 4,\n\"subjectURI\": \"http://localhost:8080/RestExampleAPI/rest/subjects/4\"\n},\n{\n\"location\": \"Creativity St\",\n\"subject\": \"Cooking\",\n\"subjectId\": 5,\n\"subjectURI\": \"http://localhost:8080/RestExampleAPI/rest/subjects/5\"\n}",
          "type": "json"
        },
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 204 NO CONTENT\n\t{\n\t\t\"Message\": \"No subjects in the list!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/SubjectResource.java",
    "groupTitle": "Subjects",
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "type": "400",
            "optional": false,
            "field": "BadRequest",
            "description": "<p>Bad Request Encountered</p>"
          }
        ]
      }
    }
  },
  {
    "type": "put",
    "url": "subjects/",
    "title": "Update a Subject",
    "name": "updateLocationOfSubject",
    "group": "Subjects",
    "description": "<p>Subject location can be updated by passing text/plain payload(in the body). Text to be sent is of the format: subjectId locationText e.g. 5 New York</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 202 ACCEPTED\n\t{\n\t\"SuccessMessage\": \"Item updated!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 400 BAD REQUEST\n\t{\n\t\t\"Error\" : \"Provide valid numeric input for Subject ID!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 406 NOT ACCEPTABLE\n\t{\n\t\t\"Error\" : \"Provide valid input!\"\n\t}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": " HTTP/1.1 500 SERVER ERROR\n\t{\n\t\t\"Server Error\" : \"Unable to process request. Try again!\"\n\t}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/edu/asupoly/ser422/restexample/api/SubjectResource.java",
    "groupTitle": "Subjects"
  }
] });
