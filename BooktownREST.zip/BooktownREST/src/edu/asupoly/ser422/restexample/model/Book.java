package edu.asupoly.ser422.restexample.model;

import java.net.URI;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;

@JacksonStdImpl
@JsonPropertyOrder({"bookId", "title", "authorId", "subjectId", "selfUri", "referer"})
public class Book {
	@JsonProperty("bookId")
	private int bookId;
	@JsonProperty("title")
	private String title;
	@JsonProperty("authorId")
	private int authorId;
	@JsonProperty("subjectId")
	private int subjectId;
	@JsonProperty("selfUri")
	private URI selfUri;
	@JsonProperty("referer")
	private URI referer;
	
	public Book() {	
	}
	
	public Book(int id, String t, int aid, int sid) {
		this.bookId = id;
		this.title = t;
		this.authorId = aid;
		this.subjectId = sid;
	}
	@JsonProperty("bookId")
	public int getBookId() {
		return bookId;
	}
	@JsonProperty("bookId")
	public void setBookId(int id) {
		this.bookId = id;
	}
	@JsonProperty("title")
	public String getTitle() {
		return title;
	}
	@JsonProperty("title")
	public void setTitle(String title) {
		this.title = title;
	}
	@JsonProperty("authorId")
	public int getAuthorId() {
		return authorId;
	}
	@JsonProperty("authorId")
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	@JsonProperty("subjectId")
	public int getSubjectId() {
		return subjectId;
	}
	@JsonProperty("subjectId")
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	@JsonProperty("selfUri")
	public URI getSelfUri() {
		return selfUri;
	}
	@JsonProperty("selfUri")
	public void setSelfUri(URI selfUri) {
		this.selfUri = selfUri;
	}
	@Override
	public String toString() {
		return "BookID "+getBookId()+", Title "+getTitle()+
				", AuthorID "+getAuthorId()+", SubjectID "+getSubjectId();
	}
	@JsonProperty("referer")
	public URI getReferer() {
		return referer;
	}
	@JsonProperty("referer")
	public void setReferer(URI referer) {
		this.referer = referer;
	}
}
