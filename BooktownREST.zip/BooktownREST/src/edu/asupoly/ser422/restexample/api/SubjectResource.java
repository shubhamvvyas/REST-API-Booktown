package edu.asupoly.ser422.restexample.api;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.fasterxml.jackson.core.JsonProcessingException;

import edu.asupoly.ser422.restexample.model.Book;
import edu.asupoly.ser422.restexample.model.AuthorBook;
import edu.asupoly.ser422.restexample.model.Subject;
import edu.asupoly.ser422.restexample.services.BooktownService;
import edu.asupoly.ser422.restexample.services.BooktownServiceFactory;

@Path("/subjects")
@Produces({MediaType.APPLICATION_JSON})
public class SubjectResource {
	private static BooktownService __bService = BooktownServiceFactory.getInstance();

	@Context
	private UriInfo _uriInfo;
	
	/**
	 * @api {get} subjects Get list of Subjects
	 * @apiName getSubjects
	 * @apiGroup Subjects
	 *
	 * @apiDescription
	 * Each of the response object has a hyperlink field "subjectURI"
	 *  which can be used
	 * to navigate to the subject.
	 * 
	 * @apiUse BadRequestError
	 * 
	 * @apiSuccessExample Success-Response:
	 *	{
	 *	"location": "Productivity Ave",
	 *	"subject": "Computers",
	 *	"subjectId": 4,
	 *	"subjectURI": "http://localhost:8080/RestExampleAPI/rest/subjects/4"
	 *	},
	 *	{
	 *	"location": "Creativity St",
	 *	"subject": "Cooking",
	 *	"subjectId": 5,
	 *	"subjectURI": "http://localhost:8080/RestExampleAPI/rest/subjects/5"
	 *	}
	 *
	 * @apiSuccessExample {json} Success-Response:
	 *  HTTP/1.1 204 NO CONTENT
	 * 	{
	 * 		"Message": "No subjects in the list!"
	 * 	}
	 * 
	 * 
	 * */
	@GET
	public Response getSubjects() {
		List<Subject> subjectList = __bService.getSubjects();
		if(subjectList == null || subjectList.size() == 0) {
			return Response.status(Response.Status.NO_CONTENT)
					.entity("{\"Message\":\"No subjects in the list!"
							+ "\"}").build();
		}
		for(Subject s : subjectList) {
			URI selfUri = _uriInfo.getBaseUriBuilder().path(SubjectResource.class).path(SubjectResource.class,
					"getSubject").build(s.getSubjectId());
			s.setSubjectURI(selfUri);
		}
		return Response.status(Response.Status.OK).entity(subjectList).build();
	}
	
	/*
	 * LAB 3 TASK 6:
	 * Subject id can be only numeric. If user provides non-numeric string,
	 * 400 BAD REQUEST is returned.
	 */
	/**
	 * @api {get} subjects/{subject_id} Get Subject by ID
	 * @apiName getSubject
	 * @apiGroup Subjects
	 * 
	 * @apiDescription
	 * getSubject is used to get Subject information based on the ID.
	 * 'SelfURI' has the hyperlink navigating to itself.
	 * "referer" attribute in the response would return 'null' if the
	 * resource is accessed using URI and would have URI of the previous
	 * resource if accessed through hyperlink.
	 *
	 * 
	 * @apiSuccessExample Success-Response:
	 * 	HTTP/1.1 200 OK
	 *	[{
	 *	"bookID": 7808,
	 *	"title": "The Shining",
	 *	"authorId": 4156,
	 *	"subjectId": 7808,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/7808",
	 *	"referer": null
	 *	}]
	 * 
	 *@apiSuccessExample {json} Success-Response:
	 *  HTTP/1.1 204 NO CONTENT
	 * 	{
	 * 		"Error": "No Content!"
	 * 	}
	 * 
	 *  @apiErrorExample Error-Response:
	 *  HTTP/1.1 400 BAD REQUEST
	 *  { 
	 *  "Error" : "Provide valid numeric input!"
	 *  }
	 * 
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 SERVER ERROR
	 * 	{
	 * 		"Error": "Internal Server Error. TRY LATER"
	 * 	}
	 * 
	 * */
	@GET
	@Path("/{subjectID}")
	public Response getSubject(@PathParam("subjectID") String subjectId, 
			@HeaderParam("referer") String ref) {
		int sid = 0;
		try {
			sid = Integer.parseInt(subjectId);
		}
		catch(Exception e){
			return Response.status(Response.Status.BAD_REQUEST).entity("{"
					+ "\"Error\": \"Provide valid"
					+ " numeric input!\"}").build();
		}
		Subject subject = __bService.getSubject(sid);
		if(subject == null) {
			return Response.status(204).entity(""
					+ "{\"Message\":\"No Content!\"}").build();
		}

		URI selfUri = _uriInfo.getBaseUriBuilder().path(SubjectResource.class).path(SubjectResource.class,
				"getSubject").build(subject.getSubjectId());
		subject.setSubjectURI(selfUri);
		try {
			if(ref != null)
				subject.setReferer(new URI(ref));
		}
		catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			return Response.status(500).entity(""
					+ "{\"Error\":\"Internal Server Error. TRY LATER"
					+ "\"}").build();
		}
		String sString = null;
		try {
			sString = SubjectSerializationHelper.getHelper().generateJSON(subject);

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			return Response.status(500).entity(""
					+ "{\"Error\":\"Internal Server Error for processing JSON."
					+ "\"}").build();
		}

		return Response.status(Response.Status.OK).entity(sString).build();
	}
	
	/*
	 * LAB 3 TASK 6:
	 * Subject id can be only numeric. If user provides non-numeric string,
	 * 400 BAD REQUEST is returned.
	 */
	/**
	 * @api {get} subjects/{subjectId}/books Get Books from Subject ID
	 * @apiName findBooksBySubject
	 * @apiGroup Subjects
	 * 
	 * @apiDescription
	 * findBooksBySubject provides the list of books for particular subject.
	 * Subject ID has to be mentioned in the URI in order to get the list
	 * 
	 *
	 * 
	 * @apiSuccessExample Success-Response:
	 *	{
	 *	"authorId": 1809,
	 *	"bookId": 1608,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/1608",
	 *	"subjectId": 2,
	 *	"title": "The Cat in the Hat"
	 *	},
	 *	  {
	 *	"authorId": 1809,
	 *	"bookId": 1590,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/1590",
	 *	"subjectId": 2,
	 *	"title": "Bartholomew and the Oobleck"
	 *	}
	 * 
	 *  @apiErrorExample Error-Response:
	 *  HTTP/1.1 400 BAD REQUEST
	 *  { 
	 *  "Error" : "Provide valid numeric input for Subject ID!"
	 *  }
	 *  
	 *  @apiSuccessExample {json} Success-Response:
	 *  HTTP/1.1 204 NO CONTENT
	 * 	{
	 * 		"Message": "No Content!"
	 * 	}
	 *  
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 INTERNAL SERVER ERROR
	 * 	{
	 * 		"Error": "Internal Server Error. TRY LATER"
	 * 	}
	 * 
	 * 
	 * */
	@GET
	@Path("/{subjectId}/books")
	@Produces("application/json")
	public Response findBooksBySubject(@PathParam("subjectId") String subjectId) {
		
		int sid = 0;
		try {
			sid = Integer.parseInt(subjectId);
		}
		catch(Exception e){
			return Response.status(Response.Status.BAD_REQUEST).entity("{"
					+ "\"Error\": \"Provide valid"
					+ " numeric input for Subject ID!\"}").build();
		}
		List<Book> bookList = __bService.findBooksBySubject(sid);
		if(bookList.size() == 0 || bookList == null) {
			return Response.status(204).entity(""
					+ "{\"Message\":\"No Content!\"}").build();
		}

		try {
			for(Book b : bookList) {
				URI selfUri = _uriInfo.getBaseUriBuilder().path(BookResource.class).path(BookResource.class,
						"getBook").build(b.getBookId());
				b.setSelfUri(selfUri);
			}
		}
		catch(Exception e) {
			return Response.status(500).entity(""
					+ "{\"Error\":\"Internal Server Error. TRY LATER"
					+ "\"}").build();
		}

		return Response.status(Response.Status.OK).entity(bookList).build();
	}
	
	/*
	 * LAB 3 TASK 6:
	 * When non-acceptable characters are sent to the string,
	 * 406 NOT ACCEPTABLE is returned.
	 */
	/**
	 * @api {put} subjects/ Update a Subject
	 * @apiName updateLocationOfSubject
	 * @apiGroup Subjects
	 * 
	 * 
	 * @apiDescription
	 * Subject location can be updated by passing text/plain payload(in the body).
	 * Text to be sent is of the format:
	 * subjectId locationText
	 * e.g. 5 New York
	 * 
	 * @apiSuccessExample Success-Response:
	 *  HTTP/1.1 202 ACCEPTED
	 *	{
	 *	"SuccessMessage": "Item updated!"
	 *	}
	 *  
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 400 BAD REQUEST
	 * 	{
	 * 		"Error" : "Provide valid numeric input for Subject ID!"
	 * 	}
	 * 
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 406 NOT ACCEPTABLE
	 * 	{
	 * 		"Error" : "Provide valid input!"
	 * 	}
	 * 
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 SERVER ERROR
	 * 	{
	 * 		"Server Error" : "Unable to process request. Try again!"
	 * 	}
	 * 
	 * */
	@PUT
	@Consumes("text/plain")
	public Response updateLocationOfSubject(String text) {
		String[] attr = text.split(" ");
		StringBuilder sb = new StringBuilder();
		String temp = "";
		int sid = 0;
		try {
			sid = Integer.parseInt(attr[0]);
		}
		catch(Exception e){
			return Response.status(Response.Status.BAD_REQUEST).entity("{"
					+ "\"Error\": \"Provide valid"
					+ " numeric input for Subject ID!\"}").build();
		}
		for(int i = 1; i < attr.length; i++) {
			sb.append(temp);
			temp = " ";
			sb.append(attr[i]);
		}
		int res = __bService.updateLocationOfSubject(sid, sb.toString());
		if(res == 0) {
			return Response.status(Response.Status.ACCEPTED).entity(""
					+ "{\"SuccessMessage\": \"Item updated!\"}").build();
		}
		else if(res < 0) {
			return Response.status(Response.Status.NOT_ACCEPTABLE).entity("{"
					+ "\"Error\": \"Provide valid"
					+ " input!\"}").build();
		}
		else {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{"
					+ "\"Server Error\": \"Unable to process "
					+ "request. Try again!\"}").build();
		}
	}
	
	/**
	 * @api {get} subjects/locations/{loc}/authors Get Authors from the Location Substring
	 * @apiName getAuthorsByLocation
	 * @apiGroup Subjects
	 * 
	 * @apiDescription
	 * getAuthorsByLocation returns a list of Authors who own a book in that
	 * Subject. URI can be provided as path-to-api/subjects/authors/locations/{loc}
	 * where loc is the location substring.
	 * 
	 *
	 * 
	 * @apiSuccessExample Success-Response:
	 *	{
	 *	"authorId": 1809,
	 *	"bookId": 1608,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/1608",
	 *	"subjectId": 2,
	 *	"title": "The Cat in the Hat"
	 *	},
	 *	  {
	 *	"authorId": 1809,
	 *	"bookId": 1590,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/1590",
	 *	"subjectId": 2,
	 *	"title": "Bartholomew and the Oobleck"
	 *	}
	 * 
	 *  @apiSuccessExample {json} Success-Response:
	 *  HTTP/1.1 204 NO CONTENT
	 * 	{
	 * 		"Message": "No Data found! Try another substring!"
	 * 	}
	 *  
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 INTERNAL SERVER ERROR
	 * 	{
	 * 		"Server Error": "Unable to process request. Try again!"
	 * 	}
	 * 
	 * 
	 * */
	@GET
	@Path("/locations/{loc}/authors")
	public Response getAuthorsByLocation(@PathParam("loc") String loc) {
		loc = loc.toUpperCase();
		Set<AuthorBook> authors = __bService.getAuthorsByLocation(loc);
		if(authors.size() == 0) {
			return Response.status(Response.Status.NO_CONTENT).entity("{"
					+ "\"Message\": \"No Data Found!"
					+ " Try another Substring!\"}").build();
		}
		else {
			try {
				for(AuthorBook a : authors) {
					URI bookUri = _uriInfo.getBaseUriBuilder().path(BookResource.class).path(BookResource.class,
							"getBook").build(a.getBookId());
					a.setBookURI(bookUri);
					
				}
			}
			catch(Exception e) {
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{"
						+ "\"Server Error\": \"Unable to process "
						+ "request. Try again!\"}").build();
			}
		}
		return Response.status(Response.Status.OK).entity(authors).build();

	}
}
