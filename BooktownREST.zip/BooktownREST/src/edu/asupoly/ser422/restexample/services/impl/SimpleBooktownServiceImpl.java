package edu.asupoly.ser422.restexample.services.impl;

import java.util.List;
import java.util.Set;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashSet;

import edu.asupoly.ser422.restexample.model.Author;
import edu.asupoly.ser422.restexample.model.AuthorBook;
import edu.asupoly.ser422.restexample.model.Book;
import edu.asupoly.ser422.restexample.model.Subject;

//A simple impl of interface BooktownService
public class SimpleBooktownServiceImpl extends ABooktownServiceImpl {
	
	// Author section
	private final static String[] fnames = {"Laura", "Hillary", "Jackie",};
	private final static String[] lnames = {"Bush", "Clinton", "Kennedy"};
	private ArrayList<Author> __authors = null;
	
	
	private final static String[] fnamesAB = {"Laura", "Hillary", "Jackie",};
	private final static String[] lnamesAB = {"Bush", "Clinton", "Kennedy"};
	private final static int[] bids = {0,0,0};
	@SuppressWarnings("unused")
	private final static URI[] bookURIs = {null,null,null};
	private ArrayList<AuthorBook> __authorsBooks = null;
	
	public List<Author> getAuthors() {
		List<Author> deepClone = new ArrayList<Author>();
		for (Author a : __authors) {
			deepClone.add(new Author(a.getAuthorId(), a.getFirstName(), a.getLastName()));
		}
		return deepClone;
	}

	public int createAuthor(String lname, String fname) {	
		int authorId = generateKey(1,99999);
		// 10 retries 
		for (int i = 0; i < 10 && !(__authors.add(new Author(generateKey(1, 99999), lname, fname))); ) {
			authorId = generateKey(1,99999);
		}
		return authorId;
    }

	public boolean deleteAuthor(int authorId) {
		boolean rval = false;
		try {
			// Find any Books pointing at this author
			Set<Book> books = new LinkedHashSet<Book>();
			for (Book b : __books) {
				if (b.getAuthorId() == authorId) {
					b.setAuthorId(-1);  // I guess -1 will mean marked for deletion
					books.add(b);
				}
			}

			Author a = getAuthor(authorId);
			if (a != null) {
				rval = __authors.remove(a);
			}
			if (!rval) {
				// if we couldn't remove that book we have to undo the books above,
				// which is why we hung onto them!
				for (Book b : books) {
					b.setAuthorId(authorId);
				}
			}
		} catch (Exception exc) {
			exc.printStackTrace();
			rval = false;
		}
		return rval;
	}
	
	@Override
	public Author getAuthor(int id) {
		for (Author a : __authors) {
			if (a.getAuthorId() == id) {
				return a;
			}
		}
		return null;
	}

	@Override
	public boolean updateAuthor(Author author) {
		boolean rval = false;
		for (Author a : __authors) {
			if (a.getAuthorId() == author.getAuthorId()) {
				rval = true;
				a.setFirstName(author.getFirstName());
				a.setLastName(author.getLastName());
			}
		}
		return rval;
	}
	
    // Book section
	private final static String[] titles = {"Sisters First", "My Turn", "Four Days"};
	private ArrayList<Book> __books = null;

    public List<Book> getBooks() {
		List<Book> deepClone = new ArrayList<Book>();
		for (Book b : __books) {
			deepClone.add(new Book(b.getBookId(), b.getTitle(), b.getAuthorId(), b.getSubjectId()));
		}
		return deepClone;
    }
    public Book getBook(int id) {
		for (Book b : __books) {
			if (b.getBookId() == id) {
				return b;
			}
		}
    		return null;	
    }
    public int createBook(String title, int aid, int sid) {
		int bookId = generateKey(1,99999);
		// 10 retries 
		for (int i = 0; i < 10 && !(__books.add(new Book(bookId, title, aid, sid))); ) {
			bookId = generateKey(1,99999);
		}
		return bookId;
    }
    
    public Author findAuthorOfBook(int bookId) {
    		Author a = null;
    		Book b = getBook(bookId);
    		if (b != null) {
    			a = getAuthor(b.getAuthorId());
    		}
    		return a;
    }
    
    
	@Override
	public int deleteBook(int bid) {
    	try {
    		for(int i = 0; i < __books.size(); i++) {
    			if(__books.get(i).getBookId() == bid) {
    				__books.remove(i);
    				return 0;
    			}
    		}
    		return -1;
		} catch (Exception exc) {
			return 1;
		}
	}
    
    // Subject section
	private final static String[] subjects = {"Humor", "Politics", "Drama"};
	private final static String[] locations = {"Midland, TX", "Little Rock, AR", "Dallas, TX"};
	private ArrayList<Subject> __subjects = null;
	
    public List<Subject> getSubjects() {
		List<Subject> deepClone = new ArrayList<Subject>();
		for (Subject s : __subjects) {
			deepClone.add(new Subject(s.getSubjectId(), s.getSubject(), s.getLocation()));
		}
		return deepClone;
    }
    public Subject getSubject(int id) {
    		for (Subject s : __subjects) {
    			if (s.getSubjectId() == id) {
    				return s;
    			}
    		}
    		return null;
    }
    public List<Book> findBooksBySubject(int subjectId) {
    	List<Book> bookList = new ArrayList<Book>();
    	for(Book b : __books) {
    		if(b.getSubjectId() == subjectId) {
    			bookList.add(b);
    		}
    	}
    	return bookList;
    }
    
	public int updateLocationOfSubject(int id, String updatedLocation) {
		// TODO Auto-generated method stub
		int res = -1;
		for(Subject s : __subjects) {
			if(s.getSubjectId() == id) {
				res = 0;
				s.setLocation(updatedLocation);
				return res;
			}
		}
		return res;
	}
    
	@Override
	public Set<AuthorBook> getAuthorsByLocation(String loc) {
		// TODO Auto-generated method stub
		Set<AuthorBook> authors = new LinkedHashSet<AuthorBook>();
		for(Subject s : __subjects) {
			if(s.getLocation().toUpperCase().contains(loc)) {
				for(Book b : __books) {
					if(b.getSubjectId() == s.getSubjectId()) {
						for(AuthorBook ab : __authorsBooks) {
							if(ab.getAuthorId() == b.getAuthorId()) {
								authors.add(new AuthorBook(ab.getAuthorId(), ab.getLastName(), 
										ab.getFirstName(), b.getBookId()));
							}
						}
					}
				}
			}
		}
		
		return authors;
	}
	
	// Only instantiated by factory?
	public SimpleBooktownServiceImpl() {
		__authors = new ArrayList<Author>();
		__books = new ArrayList<Book>();
		__subjects = new ArrayList<Subject>();
		__authorsBooks = new ArrayList<AuthorBook>();
		for (int i = 0; i < fnames.length; i++) {
			Author a = new Author(i, lnames[i], fnames[i]);
			__authors.add(a);
			Subject s = new Subject(i, subjects[i], locations[i]);
			__subjects.add(s);
			__books.add(new Book(i, titles[i], a.getAuthorId(), s.getSubjectId()));
			__authorsBooks.add(new AuthorBook(i, lnamesAB[i], fnamesAB[i], bids[i]));
		}
	}

	

	

	
}