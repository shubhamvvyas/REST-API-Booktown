package edu.asupoly.ser422.restexample.api;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.asupoly.ser422.restexample.model.Author;
import edu.asupoly.ser422.restexample.model.AuthorBook;
import edu.asupoly.ser422.restexample.model.Book;
import edu.asupoly.ser422.restexample.services.BooktownService;
import edu.asupoly.ser422.restexample.services.BooktownServiceFactory;

@Path("/books")
@Produces({MediaType.APPLICATION_JSON})
public class BookResource {
	private static BooktownService __bService = BooktownServiceFactory.getInstance();

	@Context
	private UriInfo _uriInfo;

	/**
	 * @apiDefine BadRequestError
	 * @apiError (Error 4xx) {400} BadRequest Bad Request Encountered
	 * */
	/** @apiDefine ActivityNotFoundError
	 * @apiError (Error 4xx) {404} NotFound Activity cannot be found
	 * */
	/**
	 * @apiDefine InternalServerError
	 * @apiError (Error 5xx) {500} InternalServerError Something went wrong at server, Please contact the administrator!
	 * */
	/**
	 * @apiDefine NotImplementedError
	 * @apiError (Error 5xx) {501} NotImplemented The resource has not been implemented. Please keep patience, our developers are working hard on it!!
	 * */

	/**
	 * @api {get} books Get list of Books
	 * @apiName getBooks
	 * @apiGroup Books
	 *
	 * @apiUse BadRequestError
	 * 
	 * @apiSuccessExample Success-Response:
	 * 	HTTP/1.1 200 OK
	 *[{
	 * 	"authorId": 1809,
	 *	"bookId": 1590,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/1590",
	 *	"subjectId": 2,
	 *	"title": "Bartholomew and the Oobleck"
	 *}
	 *{
	 *	"authorId": 15990,
	 *	"bookId": 25908,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/25908",
	 *	"subjectId": 2,
	 *	"title": "Franklin in the Dark"
	 *}]
	 * @apiSuccessExample Success-Response:
	 * 	HTTP/1.1 204 NO CONTENT
	 * {
	 * 	"Message": "No Books in the records!"
	 * }
	 *
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 SERVER ERROR
	 * 	{
	 * 		"message": "Request cannot be processed now. TRY AGAIN LATER!"
	 * 	}
	 * 
	 * 
	 * */
	@GET
	public Response getBooks(){

		List<Book> list = __bService.getBooks();
		/*
		ObjectMapper om = new ObjectMapper();
		List<Book> listBook = new ArrayList<Book>();
		 */
		if(list.size() == 0) {
			return Response.status(Response.Status.NO_CONTENT).
					entity("{\"Message\":\"No Books in the records!\"}").build();
		}

		try {
			for(Book b : list) {
				URI selfUri = _uriInfo.getBaseUriBuilder().path(BookResource.class).path(BookResource.class,
						"getBook").build(b.getBookId());
				b.setSelfUri(selfUri);
			}
		}
		catch(Exception e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).
					entity("{\"message\":\"Request cannot be processed now. TRY AGAIN LATER!\"}").build();
		}

		return Response.status(Response.Status.OK).entity(list).build();
	}

	/*
	 * LAB 3 TASK 6:
	 * Book id can be only numeric. If user provides non-numeric string,
	 * 400 BAD REQUEST is returned.
	 */

	/**
	 * @api {get} books/{book_id} Get Book by ID
	 * @apiName getBook
	 * @apiGroup Books
	 * 
	 * @apiDescription
	 * getBook is used to get Book information based on the ID.
	 * "referer" attribute in the response would return 'null' if the
	 * resource is accessed using URI and would have URI of the previous
	 * resource if accessed through hyperlink.
	 *
	 * 
	 * @apiSuccessExample Success-Response:
	 * 	HTTP/1.1 200 OK
	 *	[{
	 *	"bookID": 7808,
	 *	"title": "The Shining",
	 *	"authorId": 4156,
	 *	"subjectId": 7808,
	 *	"selfUri": "http://localhost:8080/RestExampleAPI/rest/books/7808",
	 *	"referer": null
	 *	}]
	 * 
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 404 NOT FOUND
	 * 	{
	 * 		"Error": "No Content!"
	 * 	}
	 * 
	 *  @apiErrorExample Error-Response:
	 *  HTTP/1.1 400 BAD REQUEST
	 *  { 
	 *  "Error" : "Provide valid numeric input!"
	 *  }
	 *  
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 SERVER ERROR
	 * 	{
	 * 		"Error": "Internal Server Error."
	 * 	}
	 * 
	 * */
	@GET
	@Path("/{bookId}")
	public Response getBook(@PathParam("bookId") String bookId, @HeaderParam("referer") String ref) {
		int bid = 0;
		try {
			bid = Integer.parseInt(bookId);
		}
		catch(Exception e){
			return Response.status(Response.Status.BAD_REQUEST).entity("{"
					+ "\"Error\": \"Provide valid"
					+ " numeric input!\"}").build();
		}
		Book book = __bService.getBook(bid);

		if(book == null) {
			return Response.status(404).entity(""
					+ "{\"Error\":\"No Content!\"}").build();
		}
		System.out.println(book.getSubjectId());

		URI selfUri = _uriInfo.getBaseUriBuilder().path(BookResource.class).path(BookResource.class,
				"getBook").build(book.getBookId());
		book.setSelfUri(selfUri);
		try {
			if(ref != null)
				book.setReferer(new URI(ref));
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			return Response.status(500).entity(""
					+ "{\"Error\":\"Internal Server Error."
					+ "\"}").build();
		}
		String bString = null;
		try {
			bString = BookSerializationHelper.getHelper().generateJSON(book);

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return Response.status(Response.Status.OK).entity(bString).build();

	}
	
	/*
	 * LAB 3 TASK 6:
	 * When content-type of the cleint is not applicatio/json,
	 * 415 UNSUPPORTED MEDIA TYPE is returned.
	 */
	/**
	 * @api {post} books/ Create a Book
	 * @apiName createBook
	 * @apiGroup Books
	 * 
	 * 
	 * @apiDescription
	 * Book record can be created by passing 'application/json' payload(in the body).
	 * Text to be sent is of the exact same format as shown below
	 * {
	 *	"title": "The Book Thief",
	 *	"authorId": 4156,
	 *	"subjectId": 5
	 *	}
	 * 
	 * @apiSuccessExample Success-Response:
	 *  HTTP/1.1 201 CREATED
	 *  	[{ "Book": "30017" }]
	 *  
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 400 BAD REQUEST
	 * 	{
	 * 		"Error": "Please check payload data and try again!"
	 * 	}
	 * 
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 415 UNSUPPORTED MEDIA TYPE
	 * 	{
	 * 		"Error": "Please use application/json as content type and check payload data!"
	 * 	}
	 * 
	 * @apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 SERVER ERROR
	 * 	{
	 * 		"Error": "Internal Server Error. TRY AGAIN LATER!"
	 * 	}
	 * 
	 * 
	 * */
	@POST
	//@Consumes("application/json")
	public Response createBook(String s) {
		
		int bid = 0;
		Book b = null;
		try {
			b = BookSerializationHelper.getHelper().consumeJSON(s);
			if(b != null) {
				bid = __bService.createBook(b.getTitle(), 
						b.getAuthorId(), b.getSubjectId());
			}
		}
		catch(Exception e) {
			return Response.status(415).entity("{\"Error\": \"Please use "
					+ "application/json as content type and check payload data"
					+ "!\"}").build();
		}
		if (bid == -1) {
			return Response.status(400).entity("{\"Error\": \"Please check payload data and "
					+ "try again!\"}").build();
		}
		else if(bid == 1) {
			return Response.status(500).entity("{\"Error\": \"Internal Server Error!"
					+ " TRY AGAIN LATER!\"}").build();
		}
		URI selfUri = _uriInfo.getBaseUriBuilder().path(BookResource.class).path(BookResource.class,
				"getBook").build(b.getBookId());
		b.setSelfUri(selfUri);
		return Response.status(201).
				header("Location", String.format("%s/%s",_uriInfo.getAbsolutePath().toString(), bid))
				.entity("{ \"Book\" : \"" + bid + "\"}").build();
	}
	
	/*
	 * LAB 3 TASK 6:
	 * Book id can be only numeric. If user provides non-numeric string,
	 * 400 BAD REQUEST is returned.
	 */
	/**
	 * @api {get} books/{bookId}/author Get Author of the Book
	 * @apiName findAuthorOfBook
	 * @apiGroup Books
	 * 
	 * @apiDescription
	 * findAuthorOfBook provides the author information based on the Book.
	 * If Author has been deleted from the record, it cannot be retrieved.
	 * 
	 *
	 * 
	 * @apiSuccessExample Success-Response:
	 *	{
	 *	"bookURI": "http://localhost:8080/RestExampleAPI/rest/books/1501",
	 *	"bookId": 1501,
	 *	"authorId": 2031,
	 *	"lastName": "Brown",
	 *	"firstName": "Margaret Wise"
	 *	}
	 * 
	 *  @apiErrorExample Error-Response:
	 *  HTTP/1.1 400 BAD REQUEST
	 *  { 
	 *  "Error" : "Provide valid numeric input!"
	 *  }
	 *  
	 *@apiErrorExample {json} Error-Response:
	 *  HTTP/1.1 500 INTERNAL SERVER ERROR
	 * 	{
	 * 		"message": "THERE SEEMS TO BE SOME ERROR ON OUR SIDE! TRY AGAIN LATER!"
	 * 	}
	 * 
	 * 
	 * */
	@GET
	@Path("/{bookId}/author")
	public Response findAuthorOfBook(@PathParam("bookId") String bookId) {
	
		int bid = 0;
		try {
			bid = Integer.parseInt(bookId);
		}
		catch(Exception e){
			return Response.status(Response.Status.BAD_REQUEST).entity("{"
					+ "\"Error\": \"Provide valid"
					+ " numeric input!\"}").build();
		}
		Author author = __bService.findAuthorOfBook(bid);
		if(author == null) {
			return Response.status(500)
					.entity("{\"message\": \"THERE SEEMS TO BE SOME ERROR ON OUR SIDE"
							+ "! TRY AGAIN LATER!\"}").build();
		}
		AuthorBook ab = new AuthorBook();
		ab.setAuthorId(author.getAuthorId());
		ab.setFirstName(author.getFirstName());
		ab.setLastName(author.getLastName());
		ab.setBookId(bid);
		URI bookUri = _uriInfo.getBaseUriBuilder().path(BookResource.class).path(BookResource.class,
				"getBook").build(ab.getBookId());
		ab.setBookURI(bookUri);

		String aString = null;
		try {
			aString = new ObjectMapper().writeValueAsString(ab);

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Response.status(Response.Status.OK).entity(aString).build();
	}
	
	
	/*
	 * LAB 3 TASK 6:
	 * Book id can be only numeric. If user provides non-numeric string,
	 * 400 BAD REQUEST is returned.
	 */
	/**
	 * @api {delete} books?id={enter_ID_here} Delete a Book
	 * @apiName deleteBook
	 * @apiGroup Books
	 * 
	 * 
	 * @apiDescription
	 * A Book can be deleted by passing id as a query parameter as shown:
	 * path-to-booktownrest-api.com/books?id={bookId}
	 * 
	 * @apiSuccessExample Success-Response:
	 *  HTTP/1.1 200 OK
	 *  {
	 *  "SuccessMessage": "Deleted item:-50022"
	 *  }
	 *  
	 * @apiErrorExample Error-Response:
	 *  HTTP/1.1 400 BAD REQUEST
	 *  { 
	 *  "Error" : "Provide valid numeric input!"
	 *  }
	 *  
	 * @apiSuccessExample Success-Response:
	 * HTTP/1.1 204 NO CONTENT
	 * { 
	 * "Message": "ID not found!" 
	 * }
	 *  
	 *  @apiErrorExample Error-Response:
	 *  HTTP/1.1 500 SERVER ERROR
	 *  {
	 *  "Server Error": "Unable to process request. Try again!"
	 *  }
	 * 
	 * */
	@DELETE
	public Response deleteBook(@QueryParam("id") String bookId) {

		int bid = 0;
		try {
			bid = Integer.parseInt(bookId);
		}
		catch(Exception e){
			return Response.status(Response.Status.BAD_REQUEST).entity("{"
					+ "\"Error\": \"Provide valid"
					+ " numeric input!\"}").build();
		}
		int res = __bService.deleteBook(bid);
		if(res < 0) {
			return Response.status(Response.Status.NO_CONTENT).entity("{"
					+ "\"Message\": \"ID not found!\"}").build();
		}
		else if(res == 0) {
			return Response.status(Response.Status.OK).entity("{"
					+ "\"SuccessMessage\": \"Deleted item:-"+bookId+"\"}").build();
		}
		else {
			return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity("{"
					+ "\"Server Error\": \"Unable to process "
					+ "request. Try again!\"}").build();
		}
	}


}
