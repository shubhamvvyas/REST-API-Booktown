define({
  "name": "BooktownREST-LAB3-VYAS",
  "version": "0.1.0",
  "description": "SER422 REST Lab3 Apidocs-Shubham Vyas",
  "title": "Booktown REST API VYAS",
  "url": "https://localhost:8080/lab3_svyas5/rest/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-03-21T02:32:11.166Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
