define({
  "name": "BooktownREST-example",
  "version": "0.1.0",
  "description": "SER422 REST example project",
  "title": "Booktown REST API",
  "url": "https://localhost:8080/RestExampleAPI/rest/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-03-10T04:11:17.769Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
