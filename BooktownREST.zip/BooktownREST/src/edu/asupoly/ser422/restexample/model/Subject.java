package edu.asupoly.ser422.restexample.model;

import java.net.URI;

public class Subject {
	private int id;
	private String subject;
	private String location;
	private URI subjectURI;
	private URI referer;
	
	public Subject() {
		
	}
	
	public Subject (int id, String s, String l) {
		this.id = id; 
		subject = s;
		location = l;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public int getSubjectId() {
		return id;
	}
	public String getSubject() {
		return subject;
	}
	public String getLocation() {
		return location;
	}
	public URI getSubjectURI() {
		return subjectURI;
	}
	public void setSubjectURI(URI subjectURI) {
		this.subjectURI = subjectURI;
	}

	public URI getReferer() {
		return referer;
	}

	public void setReferer(URI referer) {
		this.referer = referer;
	}
}
